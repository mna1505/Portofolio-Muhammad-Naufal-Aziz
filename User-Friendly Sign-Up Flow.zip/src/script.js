// Simple QR Code Generator
function generateQRCode() {
    const canvas = document.getElementById('qrCanvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const size = 116; // Canvas size for QR code
    
    canvas.width = size;
    canvas.height = size;
    
    // Simple QR-like pattern generator
    const moduleSize = 4;
    const modules = size / moduleSize;
    
    // Create a simple pattern that looks like a QR code
    const qrPattern = [];
    for (let i = 0; i < modules; i++) {
        qrPattern[i] = [];
        for (let j = 0; j < modules; j++) {
            // Create a deterministic but random-looking pattern
            qrPattern[i][j] = (i * 7 + j * 11 + i * j) % 3 === 0;
        }
    }
    
    // Add finder patterns (corners)
    const finderSize = 7;
    
    // Top-left finder
    for (let i = 0; i < finderSize; i++) {
        for (let j = 0; j < finderSize; j++) {
            if (i === 0 || i === finderSize - 1 || j === 0 || j === finderSize - 1) {
                qrPattern[i][j] = true;
            } else if (i >= 2 && i <= 4 && j >= 2 && j <= 4) {
                qrPattern[i][j] = true;
            } else {
                qrPattern[i][j] = false;
            }
        }
    }
    
    // Top-right finder
    for (let i = 0; i < finderSize; i++) {
        for (let j = 0; j < finderSize; j++) {
            const newJ = modules - finderSize + j;
            if (i === 0 || i === finderSize - 1 || j === 0 || j === finderSize - 1) {
                qrPattern[i][newJ] = true;
            } else if (i >= 2 && i <= 4 && j >= 2 && j <= 4) {
                qrPattern[i][newJ] = true;
            } else {
                qrPattern[i][newJ] = false;
            }
        }
    }
    
    // Bottom-left finder
    for (let i = 0; i < finderSize; i++) {
        for (let j = 0; j < finderSize; j++) {
            const newI = modules - finderSize + i;
            if (i === 0 || i === finderSize - 1 || j === 0 || j === finderSize - 1) {
                qrPattern[newI][j] = true;
            } else if (i >= 2 && i <= 4 && j >= 2 && j <= 4) {
                qrPattern[newI][j] = true;
            } else {
                qrPattern[newI][j] = false;
            }
        }
    }
    
    // Draw the QR pattern
    for (let i = 0; i < modules; i++) {
        for (let j = 0; j < modules; j++) {
            ctx.fillStyle = qrPattern[i][j] ? '#000000' : '#ffffff';
            ctx.fillRect(j * moduleSize, i * moduleSize, moduleSize, moduleSize);
        }
    }
}

// Add scroll animations
function handleScrollAnimations() {
    const cards = document.querySelectorAll('.card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1
    });
    
    cards.forEach(card => {
        observer.observe(card);
    });
}

// Add interactive hover effects
function addInteractiveEffects() {
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            card.style.setProperty('--mouse-x', `${x}px`);
            card.style.setProperty('--mouse-y', `${y}px`);
        });
    });
}

// Skill bar animation on scroll
function animateSkillBars() {
    const skillBars = document.querySelectorAll('.level-bar');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fillBar 1.5s ease-out forwards';
            }
        });
    }, {
        threshold: 0.5
    });
    
    skillBars.forEach(bar => {
        bar.style.width = '0';
        observer.observe(bar);
    });
}

// Initialize all features
document.addEventListener('DOMContentLoaded', () => {
    generateQRCode();
    handleScrollAnimations();
    addInteractiveEffects();
    animateSkillBars();
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});

// Add parallax effect to background
let ticking = false;

window.addEventListener('scroll', () => {
    if (!ticking) {
        window.requestAnimationFrame(() => {
            const scrolled = window.pageYOffset;
            const pattern = document.querySelector('.background-pattern');
            if (pattern) {
                pattern.style.transform = `translateY(${scrolled * 0.3}px)`;
            }
            ticking = false;
        });
        ticking = true;
    }
});
