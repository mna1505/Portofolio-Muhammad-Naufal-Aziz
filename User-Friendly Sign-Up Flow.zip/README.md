
  # User-Friendly Sign-Up Flow

  This is a code bundle for User-Friendly Sign-Up Flow. The original project is available at https://www.figma.com/design/myShlbRZe9IbZ4ybv2w063/User-Friendly-Sign-Up-Flow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  